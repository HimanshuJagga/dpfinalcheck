package Observation;

public interface Observer {
	
	void setNotification();
}
